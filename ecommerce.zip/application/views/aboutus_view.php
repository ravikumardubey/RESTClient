<ul class="breadcrumb">
	<!--<li><a href="index.html">Home</a> <span class="divider">/</span></li>
	<li class="active">Products Name</li>-->
	<?php 
		$breadCrumb = $obj->getBreadCrumb();
		foreach($breadCrumb as $breadcrumbs)
		{
			echo '<li>
					<a href="'.$breadcrumbs["link"].'">'.$breadcrumbs["name"].'</a><span class="divider">/</span>
				</li>';
		}
	?>
</ul>




<p><span style="font-family:times new roman,times,serif"><span style="font-size:14px">Reasons why shop with us</span></span></p>

<p><span style="font-size:18px"><span style="font-family:times new roman,times,serif"><strong>Convenience</strong></span></span></p>

<p><span style="font-family:times new roman,times,serif"><span style="font-size:14px">We are open 24/7. You don&rsquo;t have to stand in long queues&rsquo; as in physical store, shop in minutes at MyWebAdmin.In - Free Ecommerce Website.&nbsp;</span></span></p>

<p><span style="font-size:18px"><span style="font-family:times new roman,times,serif"><strong>Better Prices</strong></span></span></p>

<p><span style="font-family:times new roman,times,serif"><span style="font-size:14px">We offer best deals and cheap price on the products we offer.</span></span></p>

<p><span style="font-size:18px"><span style="font-family:times new roman,times,serif"><strong>Variety</strong></span></span></p>

<p><span style="font-family:times new roman,times,serif"><span style="font-size:14px">The choices customer gets on several brands and products are amazing.</span></span></p>

<p><span style="font-size:18px"><span style="font-family:times new roman,times,serif"><strong>No Crowds</strong></span></span></p>

<p><span style="font-family:times new roman,times,serif"><span style="font-size:14px">No more crowds no more standing in queues, Especially during Festivals and Special events the crowds can really give a head ache. Crowds force us to do a hurried shopping most of the time. With MyWebAdmin.In - Free Ecommerce Website shop at home.</span></span></p>

<p><span style="font-size:18px"><span style="font-family:times new roman,times,serif"><strong>Free Delivery </strong></span></span></p>

<p><span style="font-family:times new roman,times,serif"><span style="font-size:14px">We offer free, fast and safe delivery directly to your home.</span></span></p>

<p><span style="font-size:18px"><strong><span style="font-family:times new roman,times,serif">One Stop Shop</span></strong></span></p>

<p><span style="font-family:times new roman,times,serif"><span style="font-size:14px">MyWebAdmin.In - Free Ecommerce Website is an online grocery store. You can find your daily essential needs all under one roof.</span></span></p>
