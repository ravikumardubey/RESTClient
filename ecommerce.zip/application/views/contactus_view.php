<ul class="breadcrumb">
	<!--<li><a href="index.html">Home</a> <span class="divider">/</span></li>
	<li class="active">Products Name</li>-->
	<?php 
		$breadCrumb = $obj->getBreadCrumb();
		foreach($breadCrumb as $breadcrumbs)
		{
			echo '<li>
					<a href="'.$breadcrumbs["link"].'">'.$breadcrumbs["name"].'</a><span class="divider">/</span>
				</li>';
		}
	?>
</ul>
<p><span style="color:#000000">MyWebAdmin.In - Free Ecommerce Website was designed to provide the best shopping experience for online grocery shoppers.</span></p>

<p><span style="color:#000000">All your grocery needs from your fingertips at your doorstep.</span></p>

<p><span style="color:#000000">You can also place an order<!-- by calling us at</span>&nbsp;<strong><a  href="tel:+919272225599" style="font-size:16px">(+91) 9272225599</a></strong> <span style="color:#000000">or--> by email at&nbsp;</span><span style="font-size:16px"><strong><a href="mailto:support@MyWebAdmin.In - Free Ecommerce Website" style="color: rgb(0, 85, 128); line-height: 1.6em; text-decoration: none; outline: 0px;">support@MyWebAdmin.In - Free Ecommerce Website</a></strong></span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p><em>If you have experienced any problem with our services or you think of a way we can improve it, </em></p>

<p><em>Drop us a mail with the problem that you are facing as its subject at <a href="mailto:contact@MyWebAdmin.In - Free Ecommerce Website" style="color: rgb(0, 85, 128); line-height: 1.6em; text-decoration: none; outline: 0px;">contact@MyWebAdmin.In - Free Ecommerce Website</a></em></p>
