<?php
echo "Admin Test Page";
?>