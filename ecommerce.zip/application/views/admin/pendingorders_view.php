<script>
	setTimeout(function(){$(".viewbtn").attr("target","_blank");},1000);
	
	setTimeout(function(){window.location.href = window.location.href;},(1000*60*2));
</script>